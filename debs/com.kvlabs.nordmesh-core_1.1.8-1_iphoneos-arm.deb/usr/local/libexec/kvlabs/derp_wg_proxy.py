#!/usr/local/bin/python3.11
"""KVLabs NordMesh DERP/WireGuard bridge launcher.

Token-ready scaffold: validates local Meshnet material and records sanitized
readiness. The actual DERP relay protocol is intentionally gated on a fetched
mesh map/private key; no token or old state is bundled.
"""
from __future__ import annotations
import argparse, json, os, signal, socket, sys, time
from pathlib import Path
STATE=Path('/var/mobile/Library/Hermes-iOS/nordmesh')
LOG=Path('/var/mobile/Library/Logs/Hermes-iOS/NordMesh/derp_wg_proxy.log')
READY=STATE/'derp_ready.json'

def write(data):
    STATE.mkdir(parents=True, exist_ok=True); LOG.parent.mkdir(parents=True, exist_ok=True)
    READY.write_text(json.dumps(data, indent=2, sort_keys=True)+'\n'); os.chmod(str(READY),0o644)
    with LOG.open('a') as f: f.write(json.dumps(data, sort_keys=True)+'\n')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--state', default=str(STATE))
    ap.add_argument('--wg-iface', default='utun1')
    ap.add_argument('--listen', default='127.0.0.1:51820')
    ap.add_argument('--once', action='store_true')
    args=ap.parse_args()
    st=Path(args.state)
    key_ok=(st/'mesh_private_key.b64').exists() or (st/'mesh_privatekey.b64').exists()
    map_ok=(st/'meshmap.json').exists()
    conf_ok=(st/'wgmesh.conf').exists()
    data={'component':'derp_wg_proxy','status':'ready-waiting-for-token-config' if not (key_ok and map_ok) else 'config-present', 'key_present':key_ok,'meshmap_present':map_ok,'wg_conf_present':conf_ok,'wg_iface':args.wg_iface,'listen':args.listen,'updated_at':int(time.time())}
    write(data)
    if args.once or not (key_ok and map_ok):
        print(json.dumps(data, indent=2, sort_keys=True)); return 0 if (key_ok or map_ok or conf_ok) else 2
    # Keep a supervisor process alive so launcher/status plumbing can be tested.
    # Full DERP packet relay is activated after the token produces current map/key material.
    signal.signal(signal.SIGTERM, lambda s,f: sys.exit(0))
    print(json.dumps(data, indent=2, sort_keys=True), flush=True)
    while True: time.sleep(30)
if __name__=='__main__': raise SystemExit(main())
