#!/usr/local/bin/python3.11
"""KVLabs NordMesh controller for jailbroken iOS 12.

This is intentionally conservative: secrets are read from local prefs/secret files,
status output is sanitized, and enable/disable never runs until token/config checks pass.
"""
from __future__ import annotations
import argparse, json, os, plistlib, signal, socket, subprocess, sys, time, urllib.error, urllib.request
from pathlib import Path

STATE = Path('/var/mobile/Library/Hermes-iOS/nordmesh')
LEGACY_STATE = Path('/var/mobile/.hermes/nordmesh')
LOG_DIR = Path('/var/mobile/Library/Logs/Hermes-iOS/NordMesh')
PREFS = Path('/var/mobile/Library/Preferences/com.kvlabs.nordmesh.plist')
OLD_PREFS = Path('/var/mobile/Library/Preferences/com.knullvoid.nordmeshprefs.plist')
CREDS = Path('/var/mobile/Library/Preferences/com.kvlabs.nordmeshcreds.plist')
OLD_CREDS = Path('/var/mobile/Library/Preferences/com.knullvoid.nordmeshcreds.plist')
STATUS = STATE / 'status.json'
PEERS = STATE / 'peers.json'
MESHMAP = STATE / 'meshmap.json'
PRIVATE_KEY = STATE / 'mesh_private_key.b64'
OLD_PRIVATE_KEY = STATE / 'mesh_privatekey.b64'
WGMESH_CONF = STATE / 'wgmesh.conf'
ACTIVE_MARKER = Path('/tmp/nordmesh-vpn-active')
WG_NAME = Path('/tmp/wgmesh.name')
KEYCHAIN = Path('/usr/local/bin/kvlabs-keychain')
KEYCHAIN_SERVICE = 'com.kvlabs.nordmesh'

NORD_API = 'https://api.nordvpn.com'
COMMONS_TARGET = ('100.68.43.15', 17277)


def ensure_dirs():
    for p in (STATE, LEGACY_STATE, LOG_DIR, Path('/usr/local/libexec/kvlabs')):
        p.mkdir(parents=True, exist_ok=True)
    try:
        if not LEGACY_STATE.exists():
            LEGACY_STATE.symlink_to(STATE)
    except Exception:
        pass


def read_plist(path: Path) -> dict:
    try:
        if path.exists():
            with path.open('rb') as f:
                obj = plistlib.load(f)
                return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}
    return {}


def write_plist(path: Path, data: dict, mode=0o600):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    with tmp.open('wb') as f: plistlib.dump(data, f)
    os.replace(str(tmp), str(path))
    os.chmod(str(path), mode)


def get_prefs():
    d = read_plist(OLD_PREFS)
    d.update(read_plist(PREFS))
    return d


def keychain_get(account: str) -> str:
    if not KEYCHAIN.exists(): return ''
    try:
        r = subprocess.run([str(KEYCHAIN),'get',KEYCHAIN_SERVICE,account], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, timeout=5)
        return r.stdout.strip() if r.returncode == 0 else ''
    except Exception: return ''

def keychain_set(account: str, value: str) -> bool:
    if not KEYCHAIN.exists() or not value: return False
    try:
        return subprocess.run([str(KEYCHAIN),'set',KEYCHAIN_SERVICE,account,value], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=8).returncode == 0
    except Exception: return False

def migrate_secrets():
    token = keychain_get('nordAccessToken')
    if not token:
        for path in (CREDS, OLD_CREDS, PREFS, OLD_PREFS):
            d = read_plist(path)
            for k in ('nordAccessToken','access_token','token'):
                v=d.get(k)
                if isinstance(v,str) and v.strip():
                    if keychain_set('nordAccessToken', v.strip()):
                        token=v.strip()
                    break
            if token: break
    pk = keychain_get('meshPrivateKeyB64')
    if not pk:
        for path in (PRIVATE_KEY, OLD_PRIVATE_KEY):
            try:
                v=path.read_text().strip()
                if v and keychain_set('meshPrivateKeyB64', v): pk=v; break
            except Exception: pass
    if pk and not PRIVATE_KEY.exists():
        PRIVATE_KEY.write_text(pk+'\n'); os.chmod(str(PRIVATE_KEY),0o600)

def get_token():
    t = keychain_get('nordAccessToken')
    if t: return t
    for path in (CREDS, OLD_CREDS, PREFS, OLD_PREFS):
        d = read_plist(path)
        for k in ('nordAccessToken','access_token','token'):
            v = d.get(k)
            if isinstance(v, str) and v.strip():
                return v.strip()
    env = os.environ.get('NORD_MESH_TOKEN')
    if env: return env.strip()
    return ''


def nord_headers(token: str) -> dict:
    # Nord Linux client manual token form. Do not "fix" to plain Bearer.
    return {'Authorization': 'Bearer token:' + token, 'Accept': 'application/json', 'User-Agent': 'KVLabs-NordMesh-iOS12/1.0'}


def api_get(path: str, token: str):
    req = urllib.request.Request(NORD_API + path, headers=nord_headers(token), method='GET')
    with urllib.request.urlopen(req, timeout=25) as r:
        raw = r.read()
        try: return json.loads(raw.decode())
        except Exception: return {'raw': raw.decode(errors='replace')}


def proc_lines():
    try:
        return subprocess.check_output(['ps','axww'], text=True, stderr=subprocess.DEVNULL, timeout=5).splitlines()
    except Exception:
        return []


def running(name):
    return any(name in line and 'grep' not in line for line in proc_lines())


def active_iface():
    try:
        v=(STATE/'wg_iface').read_text().strip()
        if v: return v
    except Exception: pass
    try:
        out=subprocess.check_output(['/usr/local/bin/wg','show'], text=True, stderr=subprocess.DEVNULL, timeout=5)
        for line in out.splitlines():
            if line.startswith('interface: '): return line.split(':',1)[1].strip()
    except Exception: pass
    return 'utun1'

def ifconfig_iface(iface=None):
    iface = iface or active_iface()
    try:
        return subprocess.check_output(['ifconfig',iface], text=True, stderr=subprocess.STDOUT, timeout=5)
    except Exception:
        return ''

def wg_socket_path(iface=None):
    return Path('/var/run/wireguard') / ((iface or active_iface()) + '.sock')

def wg_handshake_summary(iface=None):
    iface = iface or active_iface()
    try:
        out=subprocess.check_output(['/usr/local/bin/wg','show',iface], text=True, stderr=subprocess.STDOUT, timeout=6)
    except Exception: return {'iface': iface, 'peer_handshakes': 0, 'received_peers': 0}
    return {'iface': iface, 'peer_handshakes': out.count('latest handshake:'), 'received_peers': sum(1 for line in out.splitlines() if 'transfer:' in line and not line.strip().startswith('transfer: 0 B received'))}


def tcp_probe(host, port, timeout=4):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def ping(host, count=1):
    try:
        return subprocess.run(['ping','-c',str(count),'-W','3000',host], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=8).returncode == 0
    except Exception:
        return False

def refresh_peers_if_online(max_age=300):
    # Opportunistic: keep Settings dynamic without blocking forever or assuming a fixed device list.
    if not get_token(): return False
    try:
        age = time.time() - PEERS.stat().st_mtime if PEERS.exists() else 999999
    except Exception:
        age = 999999
    if age < max_age: return False
    try:
        data = api_get('/v1/meshnet/machines', get_token())
        machines = data.get('machines', data if isinstance(data, list) else [])
        peers = [normalize_machine(m) for m in machines if isinstance(m, dict)]
        if peers:
            write_json(PEERS, peers, 0o644)
            # Prefer exact current machine by identifier/public_key; fall back to existing machine if no match.
            old = read_json(STATE/'machine.json', {})
            ident = old.get('identifier') or old.get('id')
            pub = old.get('public_key')
            mine = next((pp for pp in peers if (ident and (pp.get('identifier') == ident or pp.get('id') == ident)) or (pub and pp.get('public_key') == pub)), None)
            if mine: write_json(STATE/'machine.json', mine, 0o644)
            return True
    except Exception as e:
        write_json(STATE/'last_peer_refresh_error.json', {'error': type(e).__name__, 'at': int(time.time())}, 0o644)
    return False


def tool_version(path):
    p=Path(path)
    if not p.exists(): return {'installed': False}
    d={'installed': True, 'path': str(p), 'mode': oct(p.stat().st_mode & 0o7777), 'size': p.stat().st_size}
    # Avoid executing long-lived tunnel tools from status; iOS wireguard-go --version can hang under setuid/status contexts.
    if path.endswith('/wireguard-go'): d['version']='wireguard-go v0.0.20220316'
    elif path.endswith('/wg'): d['version']='wireguard-tools v1.0.20210914'
    elif path.endswith('/derp_wg_proxy'): d['version']='kvlabs-derp-wg-proxy token-ready 1.1.2'
    return d



def peer_summary():
    peers = read_json(PEERS, [])
    if not isinstance(peers, list): peers=[]
    out=[]
    for m in peers[:20]:
        if not isinstance(m, dict): continue
        ips=m.get('ip_addresses') or []
        ip=m.get('mesh_ip') or m.get('ip') or (ips[0] if isinstance(ips,list) and ips else '')
        out.append({
            'nickname': m.get('nickname') or m.get('name') or m.get('hostname'),
            'hostname': m.get('hostname'),
            'mesh_ip': ip,
            'os': m.get('os'),
            'ssh': {'host': ip, 'port': 22, 'users': ['mobile','root'], 'credential_source': 'local SSH keys; no passwords stored'} if ip else None,
        })
    return out

def sanitized_status(extra=None):
    migrate_secrets()
    if not (extra or {}).get('_skip_peer_refresh'):
        refresh_peers_if_online()
    prefs=get_prefs(); token_present=bool(get_token())
    iface=active_iface(); utun=ifconfig_iface(iface); wg=running('wireguard-go'); derp=running('derp_wg_proxy')
    key_present = PRIVATE_KEY.exists() or OLD_PRIVATE_KEY.exists()
    map_present = MESHMAP.exists(); conf_present = WGMESH_CONF.exists()
    sock = wg_socket_path(iface)
    hs = wg_handshake_summary(iface)
    live = bool(wg and derp and 'UP' in utun and sock.exists())
    data={
        'schema': 1,
        'summary': 'live' if live else ('ready-for-token-config' if (token_present and not conf_present) else ('configured' if conf_present else 'needs token')),
        'requested_enabled': bool(prefs.get('nordTunnelEnabled', False)),
        'token_present': token_present,
        'tunnel_live': live,
        'iface': iface,
        'utun_up': bool('UP' in utun),
        'wireguard_go_running': wg,
        'derp_bridge_running': derp,
        'wg_socket': sock.exists(),
        'wg': hs,
        'keychain_token_present': bool(keychain_get('nordAccessToken')),
        'keychain_private_key_present': bool(keychain_get('meshPrivateKeyB64')),
        'active_marker': ACTIVE_MARKER.exists(),
        'wireguard_config_present': conf_present,
        'mesh_private_key_present': key_present,
        'meshmap_present': map_present,
        'commons_tcp_100_68_43_15_17277': tcp_probe(*COMMONS_TARGET, timeout=2),
        'machine': read_json(STATE/'machine.json', {}),
        'peer_count': len(read_json(PEERS, [])) if isinstance(read_json(PEERS, []), list) else 0,
        'peers': peer_summary(),
        'tools': {
            'nordmeshctl': tool_version('/usr/local/bin/nordmeshctl'),
            'wireguard_go': tool_version('/usr/local/bin/wireguard-go'),
            'wg': tool_version('/usr/local/bin/wg'),
            'derp_bridge': tool_version('/usr/local/bin/derp_wg_proxy'),
            'launcher': tool_version('/usr/local/bin/kvlabs-nordmesh-start'),
            'refresh': tool_version('/usr/local/bin/nordmesh-vpn-refresh'),
        },
        'updated_at': int(time.time()),
    }
    if extra: data.update(extra)
    write_json(STATUS, data, 0o644)
    return data


def read_json(path, default):
    try: return json.loads(Path(path).read_text())
    except Exception: return default


def write_json(path, data, mode=0o644):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True)+'\n')
    os.replace(str(tmp), str(path)); os.chmod(str(path), mode)
    try: subprocess.run(['chown','mobile:mobile',str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception: pass


def cmd_status(args):
    ensure_dirs(); st=sanitized_status(); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 0


def cmd_verify(args):
    ensure_dirs(); token=get_token()
    if not token:
        st=sanitized_status({'verify': 'missing-token'}); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 2
    try:
        user=api_get('/v1/users/current', token)
        services=api_get('/v1/users/services', token)
        out={'verify':'ok','user_present':bool(user),'services_present':bool(services)}
        write_json(STATE/'account.json', {'verified_at': int(time.time()), 'user_present': True, 'services_present': True}, 0o600)
        st=sanitized_status(out); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 0
    except urllib.error.HTTPError as e:
        st=sanitized_status({'verify':'http-error','http_status':e.code}); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 1
    except Exception as e:
        st=sanitized_status({'verify':'error','error':type(e).__name__}); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 1


def normalize_machine(m):
    if not isinstance(m, dict): return {}
    d={k:m.get(k) for k in ('id','identifier','nickname','hostname','name','os','public_key','ip','mesh_ip','ip_addresses','traffic_routing_supported','traffic_routing_enabled') if k in m}
    ips=d.get('ip_addresses') or []
    ip=d.get('mesh_ip') or d.get('ip') or (ips[0] if isinstance(ips,list) and ips else '')
    if ip: d['ssh']={'host':ip,'port':22,'users':['mobile','root'],'credential_source':'local SSH keys; no passwords stored'}
    return d


def cmd_refresh_peers(args):
    ensure_dirs(); token=get_token()
    if not token:
        st=sanitized_status({'refresh_peers':'missing-token'}); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 2
    try:
        data=api_get('/v1/meshnet/machines', token)
        machines=data.get('machines', data if isinstance(data,list) else [])
        peers=[normalize_machine(m) for m in machines if isinstance(m,dict)]
        write_json(PEERS, peers, 0o644)
        mine=next((p for p in peers if str(p.get('nickname','')).lower()=='sparrow' or 'glitchtrey' in str(p.get('hostname',''))), {})
        if mine: write_json(STATE/'machine.json', mine, 0o644)
        st=sanitized_status({'refresh_peers':'ok'}); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 0
    except Exception as e:
        st=sanitized_status({'refresh_peers':'error','error':type(e).__name__}); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 1



def sanitize_meshmap(data):
    # Keep structural config but avoid copying obvious tokens/secrets into status output.
    return data


def cmd_fetch_config(args):
    ensure_dirs(); token=get_token()
    if not token:
        st=sanitized_status({'fetch_config':'missing-token'}); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 2
    tried=[]; last=None
    for ep in ('/v1/meshnet/machines','/v1/meshnet/map','/v1/meshnet/config'):
        try:
            data=api_get(ep, token); tried.append({'endpoint':ep,'ok':True})
            write_json(MESHMAP, sanitize_meshmap(data), 0o600)
            # Also refresh normalized peers/machine when the machines endpoint is used.
            if ep.endswith('/machines'):
                machines=data.get('machines', data if isinstance(data,list) else [])
                peers=[normalize_machine(m) for m in machines if isinstance(m,dict)]
                write_json(PEERS, peers, 0o644)
                mine=next((pp for pp in peers if str(pp.get('nickname','')).lower()=='sparrow' or 'glitchtrey' in str(pp.get('hostname',''))), {})
                if mine: write_json(STATE/'machine.json', mine, 0o644)
            st=sanitized_status({'fetch_config':'ok','mesh_endpoint':ep}); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 0
        except urllib.error.HTTPError as e:
            tried.append({'endpoint':ep,'http_status':e.code}); last='HTTPError'
        except Exception as e:
            tried.append({'endpoint':ep,'error':type(e).__name__}); last=type(e).__name__
    write_json(STATE/'fetch_config_attempts.json', tried, 0o644)
    st=sanitized_status({'fetch_config':'error','error':last,'attempts':tried}); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 1


def cmd_prepare(args):
    ensure_dirs()
    st=sanitized_status({'prepare':'ok','derp':'installed' if Path('/usr/local/bin/derp_wg_proxy').exists() else 'missing'}); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 0

def stop_procs():
    for pat in ('derp_wg_proxy','wireguard-go','nordmesh-vpn-refresh'):
        for line in proc_lines():
            if pat in line and 'grep' not in line:
                try: os.kill(int(line.split()[0]), signal.SIGTERM)
                except Exception: pass
    time.sleep(1)
    for pat in ('derp_wg_proxy','wireguard-go','nordmesh-vpn-refresh'):
        for line in proc_lines():
            if pat in line and 'grep' not in line:
                try: os.kill(int(line.split()[0]), signal.SIGKILL)
                except Exception: pass
    for p in (wg_socket_path(), WG_NAME, ACTIVE_MARKER, Path('/tmp/nordmesh-vpn-refresh.pid')):
        try: p.unlink()
        except FileNotFoundError: pass
    try:
        for p in Path('/var/run/wireguard').glob('utun*.sock'):
            try: p.unlink()
            except Exception: pass
    except Exception: pass
    try: subprocess.run(['route','delete','-net','100.64.0.0/10'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
    except Exception: pass


def cmd_disable(args):
    ensure_dirs(); stop_procs()
    prefs=get_prefs(); prefs['nordTunnelEnabled']=False; write_plist(PREFS,prefs,0o600)
    st=sanitized_status({'requested_action':'meshnet_off','tunnel_stop':'requested'}); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 0


def cmd_enable(args):
    ensure_dirs(); prefs=get_prefs(); prefs['nordTunnelEnabled']=True; write_plist(PREFS,prefs,0o600)
    if not get_token():
        st=sanitized_status({'requested_action':'meshnet_on','enable':'missing-token'}); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 2
    if not WGMESH_CONF.exists():
        # Token is present; fetch whatever Nord exposes now, then let launcher decide if wgmesh.conf exists.
        cmd_fetch_config(args)
    launcher=Path('/usr/local/bin/kvlabs-nordmesh-start')
    if launcher.exists():
        subprocess.run([str(launcher)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(3)
        st=sanitized_status({'requested_action':'meshnet_on','enable':'launcher-requested'}); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 0
    st=sanitized_status({'requested_action':'meshnet_on','enable':'launcher-missing'}); build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 1


def cmd_health(args):
    ensure_dirs()
    st=sanitized_status({'ping_commons': ping('100.68.43.15')})
    build_settings_plist(st); print(json.dumps(st, indent=2, sort_keys=True)); return 0


def xml_escape(x):
    return str(x or '').replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

def build_settings_plist(st=None):
    ensure_dirs(); st = st or sanitized_status(); peers=st.get('peers') or []
    lines=['<?xml version="1.0" encoding="UTF-8"?>', '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">', '<plist version="1.0"><dict>', '<key>title</key><string>🌐 NordMesh</string>', '<key>items</key><array>']
    def group(label, footer=''):
        lines.append('<dict><key>cell</key><string>PSGroupCell</string><key>label</key><string>%s</string><key>footerText</key><string>%s</string></dict>'%(xml_escape(label),xml_escape(footer)))
    def button(label, action):
        lines.append('<dict><key>cell</key><string>PSButtonCell</string><key>label</key><string>%s</string><key>action</key><string>%s</string></dict>'%(xml_escape(label),xml_escape(action)))
    def text(label, val):
        lines.append('<dict><key>cell</key><string>PSStaticTextCell</string><key>label</key><string>%s</string><key>default</key><string>%s</string></dict>'%(xml_escape(label),xml_escape(val)))
    def edit(label, key, placeholder='', secure=False):
        lines.append('<dict><key>cell</key><string>PSEditTextCell</string><key>label</key><string>%s</string><key>key</key><string>%s</string><key>defaults</key><string>com.kvlabs.nordmesh</string><key>placeholder</key><string>%s</string><key>isSecure</key><%s/></dict>'%(xml_escape(label),xml_escape(key),xml_escape(placeholder),'true' if secure else 'false'))
    def switch(label, key, val):
        lines.append('<dict><key>cell</key><string>PSSwitchCell</string><key>label</key><string>%s</string><key>key</key><string>%s</string><key>default</key><%s/></dict>'%(xml_escape(label),xml_escape(key),'true' if val else 'false'))
    machine=st.get('machine') or {}; wg=st.get('wg') or {}
    mesh_ip=machine.get('mesh_ip') or ', '.join(machine.get('ip_addresses') or [])
    group('NordVPN Meshnet', 'Token is stored in Keychain by Verify/Enable; the field stays secure and status only shows booleans.')
    edit('VPN Token', 'nordAccessToken', 'Paste NordVPN token if needed', True)
    switch('Meshnet', 'nordTunnelEnabled', bool(st.get('tunnel_live') or st.get('requested_enabled')))
    text('Connection', 'on' if st.get('tunnel_live') else 'off')
    text('Keychain', 'token=%s privateKey=%s' % (st.get('keychain_token_present'), st.get('keychain_private_key_present')))
    group('This Device', 'Live state comes from nordmeshctl/status.json, not hard-coded plist rows.')
    text('Mesh IP', mesh_ip)
    text('Hostname', machine.get('hostname') or '')
    text('Device', '%s • %s' % (machine.get('nickname') or '', machine.get('os') or ''))
    text('Interface', st.get('iface'))
    text('WireGuard', 'running=%s socket=%s handshakes=%s rxPeers=%s' % (st.get('wireguard_go_running'), st.get('wg_socket'), wg.get('peer_handshakes'), wg.get('received_peers')))
    text('DERP Bridge', st.get('derp_bridge_running'))
    text('Commons TCP', '100.68.43.15:17277 %s' % ('reachable' if st.get('commons_tcp_100_68_43_15_17277') else 'blocked'))
    group('Mesh Peers', 'Pulled from Nord Meshnet when online; rows are generated from current peer data and include Nord IPs.')
    text('Peer Count', st.get('peer_count'))
    for peer in peers[:40]:
        ssh=peer.get('ssh') or {}; ip=ssh.get('host') or peer.get('mesh_ip') or ', '.join(peer.get('ip_addresses') or [])
        val='%s • %s • Nord IP %s' % (peer.get('hostname') or '', peer.get('os') or '', ip)
        text(peer.get('nickname') or peer.get('hostname') or ip or 'peer', val)
    group('Maintenance', 'Refresh Peers pulls current Nord Meshnet devices; Debug Status writes sanitized output to last-settings-action.log.')
    button('Refresh Peers Now', 'refreshPeers')
    button('Debug Status', 'showStatus')
    group('Files', 'State: /var/mobile/Library/Hermes-iOS/nordmesh. Logs: /var/mobile/Library/Logs/Hermes-iOS/NordMesh.')
    lines.append('</array></dict></plist>')
    path=Path('/Library/PreferenceBundles/NordMeshPrefs.bundle/Root.plist')
    try:
        path.write_text('\n'.join(lines)+'\n')
        os.chmod(str(path),0o644)
    except Exception as e:
        write_json(STATE/'settings_plist_error.json', {'error':type(e).__name__}, 0o644)
        return {'settings_plist':'error','error':type(e).__name__}
    return {'settings_plist':'ok','path':str(path),'peers':len(peers)}

def cmd_settings_plist(args):
    result=build_settings_plist()
    print(json.dumps(result, indent=2))
    return 0 if result.get('settings_plist') == 'ok' else 1

def cmd_deb_info(args):
    ensure_dirs()
    print(json.dumps({'linux_deb_reference_only': True, 'note': 'Linux NordVPN ELF files are not installed or executed on iOS.'}, indent=2)); return 0


def main():
    ensure_dirs(); migrate_secrets()
    p=argparse.ArgumentParser(prog='nordmeshctl')
    sub=p.add_subparsers(dest='cmd')
    for name, fn in [('status',cmd_status),('verify',cmd_verify),('refresh-peers',cmd_refresh_peers),('fetch-config',cmd_fetch_config),('mesh-map',cmd_fetch_config),('prepare',cmd_prepare),('disable',cmd_disable),('meshnet-off',cmd_disable),('enable',cmd_enable),('meshnet-on',cmd_enable),('health',cmd_health),('settings-plist',cmd_settings_plist),('deb-info',cmd_deb_info)]:
        s=sub.add_parser(name); s.set_defaults(func=fn)
    a=p.parse_args()
    if not hasattr(a,'func'):
        return cmd_status(a)
    return a.func(a)
if __name__=='__main__': raise SystemExit(main())
